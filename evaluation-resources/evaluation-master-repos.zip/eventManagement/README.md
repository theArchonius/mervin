# Event Management Model Repository

This repository contains models that describe the event management system and some of its processes.
These models are for documentation purposes only and are not intended to be executed using Moka or any other model execution tool.
Any changes must be reviewed before merging into the master branch.
